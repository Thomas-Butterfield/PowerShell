﻿<#
# Example:
Register-PSFTeppScriptblock -Name "SessionHostReplacer.alcohol" -ScriptBlock { 'Beer','Mead','Whiskey','Wine','Vodka','Rum (3y)', 'Rum (5y)', 'Rum (7y)' }
#>